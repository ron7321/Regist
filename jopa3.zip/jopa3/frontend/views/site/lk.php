<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \common\models\LoginForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Личный кабинет';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-login">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>Это твой кабинет!)</p>

    <div class="row">
        <div class="col-lg-5">
            <?php $form = ActiveForm::begin(['id' => 'login-form']); ?>


                <?= $form->field($model, 'txt_osebe')->textInput(['autofocus' => true]) ?>



                <?= $form->field($model, '')->textInput(['autofocus' => true]) ?>



                 <?= $form->field($model, 'nomber_tlf')->textInput(['autofocus' => true]) ?>


            <?php ActiveForm::end(); ?>
        </div>
    </div>
</div>
